# Data files

Raw images and research annotations are not included in this public repository.

The current sample configuration expects these source files:

- `G50 X501 (1).tif`
- `G-57_40x_1_crop.jpg`
- `N75-1_100x_ppl _crop.jpg`
- `N75-1_100x_ppl _crop_polygons.npy` (verified polygons used by the current N75-1 configuration)
- `N302 X50 Unscaled.tif`
- `N304 X80 Unscaled HDR.tif`
- `T-51_ppl _crop.jpg`
- `T-51_ppl _crop2.jpg`

Place authorized copies in your data directory and point `THIN_SECTION_DATA_DIR` to it.
