# Petrographic Thin-Section Analysis with SAM2

A unified Python/Jupyter pipeline for pore detection, instance segmentation of mineral grains, and quantitative morphometric analysis of resin-impregnated petrographic thin sections.

The workflow consolidates sample-specific notebooks into one configurable pipeline. It uses **SAM2** for grain segmentation and classical image-processing / geometric measurements for pore and grain properties.

## What the pipeline does

1. Loads a thin-section image.
2. Defines the valid analysis/rock area when needed.
3. Detects blue or teal epoxy-filled pore space.
4. Applies optional CLAHE contrast enhancement for segmentation.
5. Runs tiled SAM2 automatic mask generation.
6. Filters pore, background, oversized, truncated, and duplicate masks.
7. Recovers missed grains using point-prompted SAM2.
8. Splits selected merged grains using distance-transform / watershed logic.
9. Runs a second fine-grain SAM2 pass on remaining uncovered regions.
10. Performs final size, darkness, and overlap cleanup.
11. Converts accepted grain polygons to labeled instances.
12. Measures grain morphology.
13. Computes local porosity and grain-size / roundness maps.
14. Exports tables, masks, polygons, figures, and a sample summary.

## Supported sample configurations

The current notebook contains configurations for:

- G50
- G-57
- N75-1
- N302
- N304
- T-51
- T-51_2

These configurations preserve the processing choices used for the existing analysis, including different pore-color rules, SAM2 loading modes, recovery settings, and the G50 rock-mask step.

## Main outputs

For each processed sample, the notebook can produce:

- cleaned grain segmentation image
- labeled grain mask (`.npy`)
- grain polygons (`.npy`)
- grain measurements (`.csv`, `.xlsx`)
- porosity overlay / heatmap
- local-porosity grids
- grain-size distribution
- roundness distribution
- grain-size heatmap
- roundness heatmap
- summary table

Measured grain descriptors include:

- area
- equivalent diameter
- perimeter
- orientation
- major / minor axis length
- circularity
- aspect ratio
- elongation
- solidity

## Data

Raw research images are intentionally **not included**.

Put your images (and, where relevant, verified polygon files) in a local directory and either:

```bash
export THIN_SECTION_DATA_DIR=/path/to/your/data
```

or change `DATA_DIR` near the top of the notebook.

The filenames expected by the current configurations are documented in `data/README.md`.

## Running in Google Colab

Open:

`thin_section_sam2_pipeline.ipynb`

Then:

1. Run the installation cell.
2. Select the sample in the configuration cell, for example:

```python
SAMPLE = "G50"
```

3. Set `DATA_DIR` or the `THIN_SECTION_DATA_DIR` environment variable.
4. Run the remaining cells in order.

A CUDA GPU is strongly recommended for SAM2 segmentation.

## Installation outside Colab

A starting environment can be installed with:

```bash
pip install -r requirements.txt
```

Depending on your CUDA/PyTorch setup, you may want to install the appropriate PyTorch build separately first.

## Repository structure

```text
thin-section-sam2-analysis/
├── thin_section_sam2_pipeline.ipynb
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   └── README.md
└── outputs/
    └── .gitkeep
```

## Methodological note

The current workflow is a **hybrid segmentation pipeline**: SAM2 proposes and recovers grain instances, while pore detection, mask filtering, cleanup, and morphometric measurements are handled with classical image-processing and geometry rules.

For a future machine-learning extension, manually verified masks produced by this workflow can be used as training labels for a petrography-specific semantic / instance segmentation model.

## Third-party software

This project uses:

- **SAM 2 (Segment Anything Model 2)** by Meta AI.
- **segmenteverygrain** for grain-segmentation utilities.
- OpenCV, NumPy, pandas, scikit-image, SciPy, Shapely, Matplotlib, Pillow, PyTorch, and openpyxl.

Please follow the licenses and citation guidance of those upstream projects when using this workflow in research.

## Research-data note

Before publishing raw microscope images, annotations, or derived datasets, verify that you have permission to make those research materials public. This repository intentionally excludes them by default.
